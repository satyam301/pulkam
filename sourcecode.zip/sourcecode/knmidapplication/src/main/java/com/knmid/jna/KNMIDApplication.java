package com.knmid.jna;

import java.lang.reflect.Method;

import com.sun.jna.Library;
import com.sun.jna.Native;

public class KNMIDApplication {
	
	
	
		public static void main(String[] args) throws InterruptedException {
			try {
		System.out.println("DLL Started loading");
		String libpath = System.getProperty("jna.library.path");
		System.out.println("libpath :: " + libpath);
		System.setProperty("jna.library.path", libpath);
		String serviceProviderId=args[0];
		String civilNo=args[1];
		KNMIDLibraryMapping midAuthServiceClient = (KNMIDLibraryMapping) Native.loadLibrary("MIDAuthServiceClient",KNMIDLibraryMapping.class);
		KNMIDLibraryMapping midAuthServiceClientContract = (KNMIDLibraryMapping) Native.loadLibrary("MIDAuthServiceClientContract", KNMIDLibraryMapping.class);
		System.out.println("After DLL load MIDAuthServiceClient object : "+midAuthServiceClient);		
		System.out.println("After DLL load MIDAuthServiceClientContract object : "+midAuthServiceClientContract);
		if((serviceProviderId!=null && serviceProviderId!="")&&(civilNo!=null && civilNo!="")) {
			System.out.println("GetUserCertificate ::"+midAuthServiceClientContract.GetUserCertificate(serviceProviderId, civilNo));
			Method[] methods = midAuthServiceClient.getClass().getDeclaredMethods();
			for (Method method : methods)
				System.out.println(method);
			   System.out.println("MIDAuthServiceClient========>>" +midAuthServiceClientContract);
		}else {			
			System.out.println("Please Enter serviceProviderId and civilNo");	
		}

	}
		catch(Exception ex){
			ex.printStackTrace();
			}
		}
			
}
