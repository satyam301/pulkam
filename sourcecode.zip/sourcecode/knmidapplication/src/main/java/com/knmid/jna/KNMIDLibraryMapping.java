package com.knmid.jna;

import com.sun.jna.Library;

public interface KNMIDLibraryMapping extends Library {
    public String GetUserCertificate(String serviceProviderId, String civilNo);
    public Object getFunction();
}
